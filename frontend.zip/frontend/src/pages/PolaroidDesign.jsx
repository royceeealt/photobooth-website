import React, { useState } from "react";
import useSessionStore from "../store/useSessionStore.js";
import { getPolaroidTemplate } from "../data/polaroidTemplates.js";

export default function PolaroidDesign() {
  const stripCount = useSessionStore((s) => s.stripCount);
  const capturedPhotos = useSessionStore((s) => s.capturedPhotos);
    
  const template = getPolaroidTemplate(stripCount);
  const [selectedDesign, setSelectedDesign] = useState(null);
  if (!template) {
    return (
      <main className="page">
        <section className="polaroid-design-page">
          <h1>Polaroid Design</h1>

          <p>
            Please choose a photo layout before designing your Polaroid.
          </p>
        </section>
      </main>
    );
  }

  return (
    <main className="page">
      <section className="polaroid-design-page">
        <h1>Polaroid Design</h1>

        <p>
          {template.canvas.width} × {template.canvas.height}
        </p>
{template.designs.length > 0 && (
  <button
    type="button"
    onClick={() => setSelectedDesign(template.designs[0])}
  >
    Design 1
  </button>
)}
        <div
          style={{
            position: "relative",
            width: "540px",
            maxWidth: "100%",
            aspectRatio: `${template.canvas.width} / ${template.canvas.height}`,
          }}
        >
          {/* Polaroid base */}
          {/* Polaroid design / base */}
<img
  src={selectedDesign?.image || template.baseImage}
  alt={
    selectedDesign?.name ||
    `Blank ${template.layout}-photo Polaroid`
  }
  style={{
    position: "absolute",
    inset: 0,
    width: "100%",
    height: "100%",
    objectFit: "contain",
    imageRendering: "pixelated",
  }}
/>



          {/* Captured photos */}
          {template.photoSlots.map((slot, index) => {
            const photo = capturedPhotos[index];

            if (!photo) {
              return null;
            }
            
            return (
              <img
                key={photo.id}
                src={photo.imageDataUrl}
                alt={`Captured photo ${index + 1}`}
                style={{
                  position: "absolute",
                  left: `${(slot.x / template.canvas.width) * 100}%`,
                  top: `${(slot.y / template.canvas.height) * 100}%`,
                  width: `${(slot.width / template.canvas.width) * 100}%`,
                  height: `${(slot.height / template.canvas.height) * 100}%`,
                  objectFit: "cover",
                  imageRendering: "auto",
                }}
              />
            );
          })}
          
        </div>
      </section>
    </main>
  );
}